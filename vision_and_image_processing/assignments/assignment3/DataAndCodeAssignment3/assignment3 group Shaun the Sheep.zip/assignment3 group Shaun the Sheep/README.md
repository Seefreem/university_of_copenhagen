# Source code files
The code files respect to each question set are named as "exercise_{question number}.ipynb" and saved in DataAndCodeAssignment3.

File lists:
exercise_3.py
exercise_3.py
exercise_4.py
exercise_5.py
exercise_6.ipynb
exercise_7.ipynb


# Software Environment:
Ubuntu 20.04 LTS
Python 3.11.4
opencv-python 4.8.1.78
numpy 1.23.5
scipy 1.10.1
matplotlib 3.7.1
